# Interactive particle image

A Pen created on CodePen.io. Original URL: [https://codepen.io/rlemon/pen/nRvxyp](https://codepen.io/rlemon/pen/nRvxyp).

I thought this would be cool to use for a website logo or title.  

I mocked up a quick demo here: http://jsfiddle.net/rlemon/Fcbq7/2/show/ 

Relies on pointer-events so the elements underneath can be clicked. so IE<=10 will not work correctly. 